public interface Espion {
	void utiliserRenseignements();
}
