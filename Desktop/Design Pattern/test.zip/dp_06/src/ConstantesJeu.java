public interface ConstantesJeu {
	int NBR_LIGNES = 40; // Nombre de lignes de cellules dans le jeu
	int NBR_COLONNES = 40; // Nombre de colonnes dans le jeu
	int PAD_EN_LARGEUR = 50; // Largeur en pixels du pad autour du jeu
	int PAD_EN_HAUTEUR = 100; // Hauteur en pixels du pad autour du jeu
	int LARGEUR_GRILLE = 400; // Largeur en pixels de la grille
	int HAUTEUR_GRILLE = 400; // Hauteur en pixels de la grille
}
